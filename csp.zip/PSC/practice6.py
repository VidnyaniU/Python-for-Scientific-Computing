Here are the Python programs for the requested tasks:

### 1. Generate and Print a Dictionary with Squares
```python
# Generate a dictionary containing numbers and their squares
n = 5
squares_dict = {x: x * x for x in range(1, n + 1)}
print("Sample Dictionary:", squares_dict)
```

### 2. Check if a Key Exists in a Dictionary
```python
# Check if a key exists in a dictionary
my_dict = {1: 'a', 2: 'b', 3: 'c'}
key_to_check = 2
print("Key exists:", key_to_check in my_dict)
```

### 3. Remove a Key from a Dictionary
```python
# Remove a key from a dictionary
key_to_remove = 2
if key_to_remove in my_dict:
    del my_dict[key_to_remove]
print("Updated Dictionary:", my_dict)
```

### 4. Combine Values in a List of Dictionaries
```python
from collections import Counter

# Combine values in a list of dictionaries
data = [{'item': 'item1', 'amount': 400}, {'item': 'item2', 'amount': 300}, {'item': 'item1', 'amount': 750}]
result = Counter()
for d in data:
    result[d['item']] += d['amount']
print("Combined Values:", dict(result))
```

### 5. Verify All Values in a Dictionary are the Same
```python
# Check if all values in a dictionary are the same
dict_to_check = {'a': 1, 'b': 1, 'c': 1}
all_same = len(set(dict_to_check.values())) == 1
print("All values are the same:", all_same)
```

### 6. Update List Values in a Dictionary
```python
# Update the list values in a dictionary
original_dict = {'Years': [2020, 2021, 2022], 'OddEven': ['Even', 'Odd', 'Even'], 'Digits': [20, 21, 22]}
update_values = [2023, 'Odd', 23]

for key, value in zip(original_dict.keys(), update_values):
    original_dict[key].append(value)
print("Updated Dictionary:", original_dict)
```

### 7. Remove All Elements from a Set
```python
# Remove all elements from a set
my_set = {1, 2, 3, 4}
my_set.clear()
print("Cleared Set:", my_set)
```

### 8. Union and Intersection of Two Sets
```python
# Create union and intersection of two sets
set1 = {1, 2, 3}
set2 = {2, 3, 4}
union_set = set1.union(set2)
intersection_set = set1.intersection(set2)
print("Union:", union_set)
print("Intersection:", intersection_set)
```

### 9. Find Missing Numbers Between Two Sets
```python
# Find missing numbers between two sets
set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}
missing_in_set2 = set1 - set2
missing_in_set1 = set2 - set1
print("Missing in set2:", missing_in_set2)
print("Missing in set1:", missing_in_set1)
```

### 10. Get the 4th Element from the Last of a Tuple
```python
# Get the 4th element from the last of a tuple
my_tuple = (1, 2, 3, 4, 5, 6, 7)
fourth_last = my_tuple[-4]
print("4th from last:", fourth_last)
```

### 11. Slice Items 5 to 7 from a Tuple
```python
# Slice items 5 to 7 from a tuple
slice_tuple = my_tuple[4:7]
print("Sliced Tuple:", slice_tuple)
```

### 12. Unpack a Tuple into Variables
```python
# Unpack a tuple into variables
my_tuple = (1, 2, 3, 4)
a, b, c, d = my_tuple
print("Unpacked Values:", a, b, c, d)
```

### 13. Calculate the Average Value in a Tuple of Tuples
```python
# Calculate the average value in a tuple of tuples
tuple_of_tuples = ((10, 10, 10, 12), (30, 45, 56, 45), (81, 80, 39, 32), (1, 2, 3, 4))
averages = [sum(col) / len(col) for col in zip(*tuple_of_tuples)]
print("Averages:", averages)
```

### 14. Check if an Element Appears in a Tuple of Tuples
```python
# Check if an element appears in a tuple of tuples
tuple_of_tuples = (('Red', 'White', 'Blue'), ('Green', 'Pink', 'Purple'), ('Orange', 'Yellow', 'Lime'))
element_to_check = 'White'
found = any(element_to_check in tup for tup in tuple_of_tuples)
print(f"{element_to_check} found:", found)
```

### 15. Compute the Dot-Product of Two Vectors Using Tuples
```python
# Compute dot-product of two vectors using tuples
vector1 = (1, 2, 3)
vector2 = (4, 5, 6)
dot_product = sum(a * b for a, b in zip(vector1, vector2))
print("Dot Product:", dot_product)
```


# with open ("demo.txt","r") as f:
#     # data = f.write("Hi everyone! \n We are learning Java. \n I like programming in Java")
#     # print("Successfully wrote in the file!")
#     data = f.read()

# new_data = data.replace("Java" , "Python")
# print(new_data)


def check_for_line():
    word = "Java"
    data =True
    line_no = 1
    with open("demo.txt", "r") as f:
        while data:
            data = f.readline()
            if word in data:
                print(f"Found the word at line number {line_no}")
                return
            line_no +=1 

    return -1