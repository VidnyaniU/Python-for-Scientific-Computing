import matplotlib.pyplot as plt
import numpy as np
#print(np.pi)
#print(np.sin(np.pi/2))
#print(np.tan(0))

x= np.arange(1,11)
y = np.arange(10,110,10)

x_sin = np.arange(0 , 2*np.pi , 0.1)
y_sin = np.sin(x_sin)

plt.figure(figsize=  (6,6))


plt.subplot(2,2,1)
plt.plot(x_sin,y_sin,'r--')
plt.title("Sine Curve from 0 to 2pi")
#plt.show()

#print(np.random.random((2,2)))


#print(np.random.randint(1,10,(2,2)))
#print("3 D ARRAY :: \n" , np.random.randint(1,10 , (3,4,5)))

####STRINGS#####

s1 = "bunbroon is me"
s2 = "bunbroon is human"

#print(s1+s2)
print(np.char.upper(s1))
print(np.char.split(s2))

print(np.char.replace(s1 , "bunbroon" , "vid"))
print(np.char.center("good bye bro" , 80 , "*"))
