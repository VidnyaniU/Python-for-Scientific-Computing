my_dictionary = {}
for i in range(5):
    my_dictionary[i] = i*i

print(my_dictionary)
if (3 in my_dictionary):
    my_dictionary.pop(3)
    print ("3 removed successfully!")
