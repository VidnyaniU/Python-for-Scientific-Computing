import numpy as np
a = np.array([1,2,3,4])
#print("1 D array :: " ,a)

b = np.array([[1,2,3],[5,4,7],[3,4,8]])
#print("2 D array :: " , b)

c = np.array([[[1,2,3],[5,9,7],[3,6,5],[3,9,0]]])
#print("3 D array :: " , c)

#print(a.shape)
#print(b.shape)
#print(c.shape)

#print(b.transpose())
#print(np.empty((4,4),dtype = int))
x = np.ones(6 , dtype = int)
#print(x)

y = np.ones((3,2) , dtype = float)
#print(y)

#np.arange(start,end,step)
a = np.arange(2,20,2)
#print(a)

a = a.reshape((3,3))
#print(a)

a = a.flatten()
#print(a)

#array slicing
arr = np.arange(1, 51)
arr = arr.reshape(10,5)
#print(arr)
#print("First row :: " , arr[0])
#print("First row second col :: ",arr[0][1])
#print(arr[2:5])
#print(arr[: , 2])
print(arr[2:5 ,4])

