

    

# with open ("demo.txt","r") as f:
#     # data = f.write("Hi everyone! \n We are learning Java. \n I like programming in Java")
#     # print("Successfully wrote in the file!")
#     data = f.read()

# new_data = data.replace("Java" , "Python")
# print(new_data)


def check_for_line():
    word = "Java"
    data =True
    line_no = 1
    with open("demo.txt", "r") as f:
        while data:
            data = f.readline()
            if word in data:
                print(f"Found the word at line number {line_no}")
                return
            line_no +=1 

    return -1

print(check_for_line())
print("Hello World!")
def noice():
    pass
