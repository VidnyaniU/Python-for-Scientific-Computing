import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('./taxonomic_dataset.csv')
# Fill NaN values in 'order' and 'family' with 'Unknown'
df['order'] = df['order'].fillna('Unknown')
df['family'] = df['family'].fillna('Unknown')

# Drop columns with excessive missing values like 'infraspecificEpithet' and 'verbatimScientificNameAuthorship'
df = df.drop(columns=['infraspecificEpithet', 'verbatimScientificNameAuthorship'])

# Remove rows where 'countryCode' is missing
df = df.dropna(subset=['countryCode'])

# Standardize country codes (uppercase)
df['countryCode'] = df['countryCode'].str.upper()

# Check if the data is clean
# print(df.head())
import plotly.express as px

# Group data by country to count the number of species
species_by_country = df.groupby('countryCode').size().reset_index(name='speciesCount')

# Visualize species richness per country using a choropleth map
fig = px.choropleth(species_by_country, 
                    locations="countryCode", 
                    locationmode="ISO-3", 
                    color="speciesCount", 
                    hover_name="countryCode", 
                    color_continuous_scale="YlGn", 
                    title="Species Richness by Country")

fig.show()

# Analysis of taxonomic diversity by family
# taxonomic_diversity = df['family'].value_counts().reset_index(name='speciesCount').rename(columns={'index': 'family'})

# # Bar plot of taxonomic diversity by family
# fig2 = px.bar(taxonomic_diversity, 
#               x='family', 
#               y='speciesCount', 
#               title="Taxonomic Diversity by Family",
#               labels={'speciesCount': 'Number of Species', 'family': 'Family'},
#               text='speciesCount')

# fig2.show()